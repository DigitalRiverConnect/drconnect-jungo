﻿// NAVIGATION
// requires jquery, jquery.cookie 
var n2nav = new Object();

n2nav.linkContainerId = null;
n2nav.hostName = window.location.hostname;
n2nav.toRelativeUrl = function(absoluteUrl) {
	if(absoluteUrl.indexOf(n2nav.hostName)>0)
		return absoluteUrl.replace(/.*?:\/\/.*?\//, "/");
	return absoluteUrl;
};
n2nav.onUrlSelected = null;
n2nav.findLink = function(el) {
	while(el && el.tagName != "A")
		el = el.parentNode;
	return el;
};
n2nav.displaySelection = function(el){
	$(".selected").removeClass("selected");
	$(el).addClass("selected");
};
n2nav.getPath = function(a) {
	return $(a).attr("data-path");
};
n2nav.onTargetClick = function(el){
	n2nav.displaySelection(el);
	if(n2nav.onUrlSelected)
		n2nav.onUrlSelected(n2nav.getPath(el));
};
n2nav.handlers = {
	fallback: function() {
		n2nav.onTargetClick(this);
		n2ctx.update({ 
			path: n2nav.getPath(this), 
			previewUrl: this.href,
			permission: $(this).attr("data-permission"),
			sender: "n2nav.handlers.fallback"
		});
	}
};

n2nav.setupToolbar = function(path, url) {
	n2ctx.update({
		path: path, 
		previewUrl: url,
		sender: "n2nav.setupToolbar"
	});
};
n2nav.update = function (options) {
	if (window.console) {
		console.log("> n2nav.update " + JSON.stringify(options));
	}
	n2ctx.update(options);
};
// EDIT
var n2toggle = {
	show: function(btn, bar) {
		$(btn).addClass("toggled").blur();
		$(bar).show();
		$.cookie(bar, "show");
	},
	hide: function(btn, bar) {
		$(btn).removeClass("toggled").blur();
		$(bar).hide();
		$.cookie(bar, null);
	}
};

var initn2context = function (w) {
	"use strict";

	if (w.n2ctx)
		return w.n2ctx;

	try {
		if (w.name != "top" && w != w.parent) {
			w.n2ctx = initn2context(w.parent);
			return w.n2ctx;
		}
	} catch (e) { }

	w.n2ctx = {
		selectedPath: "/",
		_path: "/",
		selectedUrl: null,
		memorizedPath: null,
		actionType: null,

		// whether there is a top frame
		hasTop: function () {
			return false;
		},

		// selects a toolbar item by name
		toolbarSelect: function (name) {
			w.n2.select(name);
		},

		// copy/paste
		memorize: function (selected, action) {
			this.memorizedPath = selected;
			this.actionType = action;
		},
		getSelected: function () {
			return this.selectedPath;
		},
		path: function (value) {
			if (arguments.length == 0)
				return this._path;

			this._path = value;
			return this;
		},
		getSelectedUrl: function () {
			return this.selectedUrl;
		},
		getMemory: function () {
			return encodeURIComponent(this.memorizedPath);
		},
		getAction: function () {
			return encodeURIComponent(this.actionType);
		},

		initToolbar: function () {
			$(".command a").click(function () {
				if (this.hash == "#stop") {
					e.preventDefault();
					e.stopPropagation();
				}
			});
		},

		// selection memory
		update: function (options) {
			options.previewUrl = options.previewUrl || this.selectedUrl;
			this.selectedPath = options.path;
			this.selectedUrl = options.previewUrl;

			if (window.console) {
				console.log(">> n2ctx.update " + JSON.stringify(options));
			}

			if (!this.hasTop()) return;

			var memory = this.getMemory();
			var action = this.getAction();

			var formats = {
				url: options.previewUrl,
				selected: options.path,
				selectedver: options.path,
				memory: memory,
				action: action
			};
			
			if (options.versionIndex && options.versionIndex > 0) {
				formats.selectedver = options.path + '&versionIndex=' + options.versionIndex;
			}
			
			// update frame title
			if (options.title) {
				if (options.versionIndex) {
					$("#contentInfo").text(options.title + " v" + options.versionIndex);
				} else {
					$("#contentInfo").text(options.title);
				}
			}

			// update cookie http://cdmckay.org/blog/2012/02/12/creating-asp-net-httpcookie-compatible-multi-valued-cookies-in-javascript/
			if (formats.selected) {
				var value = "selected=" + escape(formats.selected);
				if (options.versionIndex && options.versionIndex > 0) value += "&versionIndex=" + options.versionIndex;
				document.cookie = "n2content=" + value + "; path=/";
			}

			// expand templates - replace {tag} with value from options	
			$("a.templatedurl").each(function () {
				var href, tmpl = href = $(this).attr("data-url-template") || a.href;
				if (href.indexOf("{") >= 0) {
					for (var key in formats) {
						var format = "{" + key + "}";
						if (href.indexOf(format) >= 0 && formats[key] == "null") {
							href = "#stop";
							$(this).addClass("disabled");
							break;
						}
						else $(this).removeClass("disabled");

						href = href.replace(format, formats[key]);
					}
					//if (tmpl != href) { console.log($(this).html() + " >> " + tmpl + " -> " + href); }
					this.href = href.replace("{query}", href.indexOf('?') >= 0 ? "&" : "?");
				}
			});

			$(document).ready(function () {
				w.document.getElementById("permission").className = options.permission;
			});
		},

		append: function (url, data) {
			return url + (url.indexOf('?') >= 0 ? "&" : "?") + $.param(data);
		},

		/// update frames
		/// * previewUrl: url to load preview frame
		/// * navigationUrl: url to load navigation frame
		/// * force: force navigation refresh (default true)
		/// * path: update path to
		refresh: function (options) {
			if (window.console) { console.log("** n2ctx.refresh: " + JSON.stringify(options)); }

			options = $.extend({ previewUrl: null, navigationUrl: null, force: true,
				showPreview: function () {
					var previewFrame = w.document.getElementById("previewFrame");
					previewFrame.src = this.previewUrl;
				},
				showNavigation: function (ctx) {
					var navigationFrame = w.document.getElementById("navigationFrame");
					navigationFrame.src = ctx.append(this.navigationUrl, { location: ctx.location });
				}
			}, options);

			if (this.hasTop()) {

				if (options.previewUrl) {
					if (w.frames.preview && w.frames.preview.onPreviewing)
						w.frames.preview.onPreviewing(options);
					options.showPreview();
				}
				if (options.navigationUrl) {
					if (w.frames.navigation && w.frames.navigation.onNavigating)
						w.frames.navigation.onNavigating(options);
					options.showNavigation(this);
				}
				else if (options.refreshTree) {
					// Defect ID : 1614 if (window.console) { console.log("** n2ctx.refresh TREE " + w.frames.navigation); }
					w.frames.navigation.location.reload();
				}

			} else if (options.previewUrl) {
				window.location = options.previewUrl;
			}
			if (options.path)
				this.path(options.path);

			options.sender += " via refresh";
			this.update(options);
		},

		// toolbar selection
		select: function (name) {
			if (!name) return;

			var $s = $("#" + name);
			n2.unselectFrame($s.find("a").attr("target"));
			$s.addClass("selected");
			$(document.body).addClass(name + "Selected");
		},
		unselectFrame: function (frame) {
			$(".selected a").filter(function () { return this.target === frame || !this.target; })
				.closest(".selected")
				.each(function () {
					n2.unselect(this.id);
				});
		},
		unselect: function (name) {
			if (!name) return;

			$("#" + name).removeClass("selected");
			$(document.body).removeClass(name + "Selected");
		}
	};

	return w.n2ctx;
};
window.n2 = initn2context(window);

window.n2.layout = {
	init: function () {
		$("#splitter-container,.pane").layout({ useStateCookie: true, cookie: { expires: 365 }, defaults: { spacing_closed: 12 }, north: { resizable: false }, west: { minWidth: 250 }, center: { minWidth: 250} });
		$("#permission").css({ position: "" }); // restore north pane style so drop-downs arn't hidden
	}
};